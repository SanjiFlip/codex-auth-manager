---
name: research-review
description: 组织科研问题、证据与验证计划。
---

# Research review

区分事实、假设和待核实结论。