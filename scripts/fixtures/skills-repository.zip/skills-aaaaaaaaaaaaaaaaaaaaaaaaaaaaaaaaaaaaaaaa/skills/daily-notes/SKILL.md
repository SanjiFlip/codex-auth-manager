---
name: daily-notes
description: 整理日常工作笔记与待办事项。
---

# Daily notes

记录已决定事项与待确认问题。